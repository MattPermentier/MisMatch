# MisMatch
## Installatie
Deze map bevat de broncode van de plug-in. Om het op WordPress te installeren
moet je het geheel in `/wordpress/wp-content/plugins` plaatsen. Vervolgens kun
je in de WordPress interface naar Plugins gaan en "MisMatch" activeren.
